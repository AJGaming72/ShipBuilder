name = "Shipbuilder";
hidePicture = "true";
hideName = "false";
actionName = "Github";
action = "https://github.com/AJGaming72/ShipBuilder";
description = "Shipbuilder is a mod that allows you to build ships in ARMA 3. Idk I just be ballin fr";